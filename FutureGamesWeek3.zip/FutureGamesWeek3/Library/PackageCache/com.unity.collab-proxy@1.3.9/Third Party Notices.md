This package contains third-party software components governed by the license(s) indicated below:
---------
Component Name: [provide component name]

License Type: [Provide license type, i.e. "MIT", "Apache 2.0"]

[Provide License Details]

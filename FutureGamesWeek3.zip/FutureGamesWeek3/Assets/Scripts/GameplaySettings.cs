﻿//@Author: Teodor Tysklind / FutureGames / Teodor.Tysklind@FutureGames.nu

using UnityEngine;

namespace FGWeek3
{
    public static class GameplaySettings
    {
        public static Vector2 mouseSensitivity = Vector2.one;
    }
}

